import { v4 as uuidv4 } from 'uuid';
import Group from '../db/models/groupModel';
import { Group as GroupType } from '../db/data';

export const findGroupById = async (id: string) => {
  return await Group.findByPk(id);
};

export const getAllGroups = async () => {
  return await Group.findAll();
};

export const createGroup = async ({ name }: GroupType) => {
  const newGroup = {
    name,
    id: uuidv4(),
  };
  return await Group.create(newGroup);
};

export const updateGroup = async (
  oldGroup: GroupType,
  newFields: Partial<GroupType>,
) => {
  const newGroup = {
    ...oldGroup,
    ...newFields,
  };
  return await Group.update(newGroup, {
    where: {
      id: oldGroup.id,
    },
  });
};

export const deleteGroupById = async (id: string) => {
  return await Group.destroy({ where: { id } });
};
