import express from 'express';
import * as dotenv from 'dotenv';
import db from './db';
dotenv.config();
import userRouter from './routers/userRouter';
import groupRouter from './routers/groupRouter';

const app = express();

app.use(express.json());

app.use('/api/users', userRouter);
app.use('/api/groups', groupRouter);

const port = process.env.PORT ?? 3000;

app.listen(port, () => {
  console.log(`Listening on ${port}`);
});

db.sequelize.sync({ force: true });
