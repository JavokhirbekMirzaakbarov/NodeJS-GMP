import db from '..';
import { Group as GroupAttributes } from '../data';
import { DataTypes, ModelDefined, Optional } from 'sequelize';

type GroupCreationAttributes = Optional<GroupAttributes, 'id' | 'permissions'>;

const Group: ModelDefined<GroupAttributes, GroupCreationAttributes> =
  db.sequelize.define(
    'Group',
    {
      id: {
        type: DataTypes.UUIDV4,
        allowNull: false,
        primaryKey: true,
      },
      name: {
        type: DataTypes.STRING,
        allowNull: false,
      },
      permissions: {
        type: DataTypes.ARRAY(
          DataTypes.ENUM('READ', 'WRITE', 'DELETE', 'SHARE', 'UPLOAD_FILES'),
        ),
        defaultValue: 'READ',
      },
    },
    {
      tableName: 'groups',
    },
  );

// populate db with some groups
// (async () => {
//   await sequelize.sync({ force: true });
//   groups.map(async (group) => await Group.create(group));
// })();

export default Group;
