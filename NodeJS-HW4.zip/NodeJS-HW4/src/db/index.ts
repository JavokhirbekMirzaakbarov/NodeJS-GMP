import path from 'path';
import fs from 'fs';
import { Sequelize, DataTypes } from 'sequelize';
const db: Record<string, any> = {};
const models = path.join(__dirname, 'models');
const BASENAME = 'index.js';

const sequelize = new Sequelize(
  `postgres://${process.env.DB_USER}:${process.env.DB_PASSWORD}@${process.env.DB_SERVER}/${process.env.DB_NAME}`,
);

fs.readdirSync(models)
  .filter(function (file: string) {
    return (
      file.indexOf('.') !== 0 && file !== BASENAME && file.slice(-3) === '.js'
    );
  })
  .forEach(function (file: string) {
    // Sequelize version <= 5.x
    // var model = sequelize['import'](path.join(models, file));
    // Sequelize version >= 6.x
    var model = require(path.join(models, file))(sequelize, DataTypes);
    db[model.name] = model;
  });

Object.keys(db).forEach(function (modelName) {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

db.Sequelize = Sequelize; // for accessing static props and functions like Op.or
db.sequelize = sequelize; // for accessing connection props and functions like 'query' or 'transaction'

export default db;
